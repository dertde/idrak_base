<?php

/**
 * @author 
 * @copyright 2010
 */
include "func_lib.php";

$row_client_id = '1';



$f_tab = 't_za_ob';
echo '-'.$row_client_id;
$f_tab = f_t_client_pw($row_client_id);
echo '-'.$f_tab;
?>